package STEP_DEF_PKG;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class testcucum extends Get_Excel{
	static WebDriver dr;
	String m1="mohankumar199898@gmail.com";

	@Given("^Browser is launched & login page displayed$")
	public void browser_is_launched_login_page_displayed()  {
		get_Excel();
		System.out.println("Browser is launched & login page displayed");
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		 dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");

	    
	}

	@When("^User enters login credentials & clicks on login$")
	public void user_enters_login_credentials_clicks_on_login()  {
		System.out.println("User enters login credentials & clicks on login");
		int row=0;
		
		System.out.println(testdata[row][0]+"  "+testdata[row][1]);
//		String arg1=testdata[row][1];
//		String arg2=testdata[row][2];
		String Username=testdata[row][0];
		String Password=testdata[row][1];
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		dr.findElement(By.xpath("//input[@class='email']")).sendKeys(Username);
		dr.findElement(By.xpath("//input[@class='password']")).sendKeys(Password);
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		row++;
		
	}

	@Then("^sucessful login happens & profile name displayed correctly$")
	public void sucessful_login_happens_profile_name_displayed_correctly()  {
		System.out.println("successful login happens & profile name displayed correctly");
		
		String s1=dr.findElement(By.xpath("//a[@class='account']")).getText();
		
		if(s1.equals(m1))
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("Fail");
		}
		
		
	}
}
