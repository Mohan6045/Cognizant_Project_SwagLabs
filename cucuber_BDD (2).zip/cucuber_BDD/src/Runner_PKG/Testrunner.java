package Runner_PKG;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="FEATURES",glue="STEP_DEF_PKG")


public class Testrunner extends AbstractTestNGCucumberTests{
	
}
