package Runner_PKG;



import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="src\\main\\resources\\FEATURE",glue="STEP_DEF_PKG")

public class TestRunner12 extends AbstractTestNGCucumberTests {
  
}
