package Runner_PKG1;



import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="src\\main\\resources\\FEATURE",glue="STEP_DEF_PKGFirefox")

public class TestRunner extends AbstractTestNGCucumberTests {
  
}
