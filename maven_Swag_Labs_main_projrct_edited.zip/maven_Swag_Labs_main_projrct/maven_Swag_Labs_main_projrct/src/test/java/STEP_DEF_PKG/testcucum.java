package STEP_DEF_PKG;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Base_Class.Get_Excel;
import Base_Class.WrapperClass;
import Pages.About_Page;
import Pages.AddtoCart_Page;
import Pages.Login_page;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class testcucum extends Get_Excel{
	static WebDriver dr;
	Login_page Ln;

	@Given("^Browser is launched & login page displayed$")
	public void browser_is_launched_login_page_displayed()  {
		get_Excel();
		 dr=WrapperClass.Launch_browser("CHROME","https://www.saucedemo.com/");
		 dr.manage().window().maximize();

	    
	}

	@When("^User enters valid login credentials  of set (\\d+) & clicks on login$")
	public void user_enters_valid_login_credentials_of_set_clicks_on_login(int arg1)  {
		System.out.println("User enters login credentials & clicks on login");
		int row=arg1;
		String Username=testdata[row][0];
		String Password=testdata[row][1];
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 Login_page Ln=new Login_page(dr);
		  System.out.println(Username+" "+Password);
		Ln.Total_Login(Username,Password);
		
	}

	@Then("^Select the Name AtoZ and Add to Cart the items$")
	public void select_the_Name_AtoZ_and_Add_to_Cart_the_items() throws InterruptedException  {
		System.out.println("successful login happens & profile name displayed correctly");
		
		 AddtoCart_Page A1=new AddtoCart_Page(dr);
		  A1.SearchA2Z();
		  A1.Addtocart_btn();
		  A1.verify_AddtoCart();
	}
		@Then("^Moving to About page and Click the Learn_More$")
		public void moving_to_About_page_and_Click_the_Learn_More() throws InterruptedException {
			 About_Page A2=new About_Page(dr);
			  A2.link_for_aboutpage();
			  A2.About_Saucedemo();
			  A2.any_btn();
			Thread.sleep(200);
			dr.close();
		}
	
		
		// for  Invalid Username and Password
		
		
		@When("^User enters Invalid login credentials  of set (\\d+) & clicks on login$")
		public void user_enters_Invalid_login_credentials_of_set_clicks_on_login(int arg1) {
			int row=arg1;
			String Username=testdata[row][0];
			String Password=testdata[row][1];
			dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			  Ln=new Login_page(dr);
			  System.out.println(Username+" "+Password);
			Ln.Total_Login(Username,Password);
			dr.close();
		}

		@Then("^Display an Error message with Invalid credentials$")
		public void display_an_Error_message_with_Invalid_credentials() {
			
			
			System.out.println(Ln.Error);

			
			
		}
		
		
		
		
		
		
}
