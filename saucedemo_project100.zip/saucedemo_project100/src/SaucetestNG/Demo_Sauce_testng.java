package SaucetestNG;

import org.testng.annotations.Test;

import Pages.About_Page;
import Pages.AddtoCart_Page;
import Pages.Login_page;
import utilities.Get_Excel;
import utilities.Library;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.DataProvider;

public class Demo_Sauce_testng extends Get_Excel{
	
	 static WebDriver dr;
	 
	 @BeforeClass
	  public void beforeMethod() {
		 get_Excel();
		  dr=Library.Launch_browser("CHROME","https://www.saucedemo.com/");
		  
	  }
  @Test(dataProvider="logindata")
  public void Logindata(String Username,String Password) {
	  System.out.println("mohan");
	 Login_page Ln=new Login_page(dr);
	  System.out.println(Username+" "+Password);
	Ln.Total_Login(Username,Password);
  }
  
  @DataProvider(name="logindata")
  public String[][] data_Provider() {
	  System.out.println("return data");
	  return testdata;
  }
  
  @Test(priority=1)
  public void searchA2B()
  {
	  AddtoCart_Page A1=new AddtoCart_Page(dr);
	  A1.SearchA2Z();
	  A1.Addtocart_btn();
  }
  
  
  @Test(priority=2)
  public void AboutPage() throws InterruptedException
  {
	  About_Page A2=new About_Page(dr);
	  A2.link_for_aboutpage();
	  A2.About_Saucedemo();
	  A2.any_btn();
  }
  
  
  
  
  
  
  
  
  
  
  
  
  

  

}
