package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Get_Excel {
	
	public static String[][] testdata=new String[1][2];
	
	public  static void get_Excel()
	
	{
		
		try {
			File f1=new File("C:\\Users\\mohan\\Desktop\\cts main project Excel\\LOgin _data.xlsx");
			FileInputStream fI=new FileInputStream(f1);
			XSSFWorkbook wb=new XSSFWorkbook(fI);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow R1=sh.getRow(0);
			for(int i=0;i<=1;i++)
			{
				
			XSSFCell c1=R1.getCell(i);
			
			testdata[0][i]=c1.getStringCellValue();
			System.out.println(testdata[0][i]);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	

}
